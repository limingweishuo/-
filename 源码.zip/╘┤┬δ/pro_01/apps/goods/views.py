import math

import jsonpickle
from django.core.cache import cache
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import render, redirect
from django.views import View
from django_redis import get_redis_connection

from goods.models import GoodsType, IndexGoodsBanner, IndexPromotionBanner, GoodsSKU, IndexTypeGoodsBanner


# Create your views here.
from order.models import OrderGoods


class IndexView(View):
    '''首页模型类'''
    def get(self,request):
        # 获取缓存数据
        context = cache.get('index_page_info')

        if context is None:

            # 获取商品分类信息
            types = GoodsType.objects.all()

            # 获取首页商品轮播图
            goods_banner = IndexGoodsBanner.objects.all().order_by('index')

            # 获取首页商品促销表
            goods_promotion = IndexPromotionBanner.objects.all().order_by('index')

            for type in types:
                title_content = IndexTypeGoodsBanner.objects.filter(type=type,display_type = 0)
                image_content = IndexTypeGoodsBanner.objects.filter(type=type,display_type = 1)

                type.title_content = title_content
                type.image_content = image_content


            # 组织上下文
            context = {
                'types':types,
                'goods_banner':goods_banner,
                'goods_promotion':goods_promotion,
            }

            # 缓存设置
            cache.set('index_page_info',context,3600)

        # 获取购物车数量
        cart_count = 0
        user = ''
        if 'user' in request.session:
            user = jsonpickle.loads(request.session.get('user'))

            con = get_redis_connection('default')
            cart_key = 'cart_%d'%user.id
            cart_count = con.hlen(cart_key)

        # 动态添加cart_count属性
        context.update(cart_count=cart_count)

        return render(request,'index.html',context)


class DetailView(View):
    '''详情页'''
    def get(self,request):

        # 获取商品id
        goods_id = request.GET.get('goods_id')

        # 获取商品信息
        try:
            sku = GoodsSKU.objects.get(id=goods_id)
        except GoodsSKU.DoesNotExist:
            return redirect('/index/')

        # 获取分类信息
        types = GoodsType.objects.all()

        # 获取新品推荐
        new_sku = GoodsSKU.objects.filter(type=sku.type).order_by('-create_time')[:2]

        # 获取同类商品SPU
        same_sku_spu = GoodsSKU.objects.filter(goods=sku.goods).exclude(id=goods_id)

        # 获取评论信息
        sku_order = OrderGoods.objects.filter(sku=sku).exclude(comment='')

        # 获取购物车数量
        cart_count = 0
        user = ''
        if 'user' in request.session:
            user = jsonpickle.loads(request.session.get('user'))

            con = get_redis_connection('default')
            cart_key = 'cart_%d' % user.id
            cart_count = con.hlen(cart_key)

            # 添加用户的历史浏览记录
            history_key = 'history_%d' % user.id

            # 移除列表中的goods_idk重复元素
            con.lrem(history_key, 0, goods_id)  # lrem 移除列表中与参数VALUE相等的元素

            # 把goods_id插入到列表的左侧
            con.lpush(history_key, goods_id)  # lpush 将一个或多个值插入到列表头部

            # 只保存用户最新浏览的5条信息
            con.ltrim(history_key, 0, 4)  # ltrim 对一个列表进行修剪 start end


        context = {
            'types':types,
            'sku':sku,
            'new_sku':new_sku,
            'sku_order':sku_order,
            'cart_count':cart_count,
            'same_sku_spu':same_sku_spu,
        }

        return render(request,'detail.html',context)


class ListView(View):
    '''列表'''
    def get(self,request,type_id):

        # 获取当前商品分类信息
        type = GoodsType.objects.get(id=type_id)

        # 获取分类信息
        types = GoodsType.objects.all()


        # 获取新品信息
        new_skus = GoodsSKU.objects.filter(type=type).order_by('-create_time')[:2]

        sort = request.GET.get('sort','')
        if sort == 'price':
            skus=GoodsSKU.objects.filter(type=type).order_by('-price')
        elif sort == 'hot':
            skus=GoodsSKU.objects.filter(type=type).order_by('sales')
        else:
            sort = 'default'
            skus=GoodsSKU.objects.filter(type=type).order_by('-id')

        # 分页器
        page_skus = Paginator(skus, 5)

        num = request.GET.get('num', 1)
        num = int(num)

        try:
            page_list = page_skus.page(num)
        except PageNotAnInteger:
            page_list = page_skus.page(1)
        except EmptyPage:
            page_list = page_skus.page(page_skus.num_pages)

        begin = (num - int(math.ceil(4.0 / 2)))
        if begin < 1:
            begin = 1

        end = begin + 3
        if end > page_skus.num_pages:
            end = page_skus.num_pages

        if end <= 4:
            begin = 1
        else:
            begin = end - 3

        page_num = range(begin, end + 1)

        user = ''
        cart_count = 0
        if 'user' in request.session:
            user = jsonpickle.loads(request.session.get('user'))

            con = get_redis_connection('default')
            cart_key = 'cart_%d' % user.id
            cart_count = con.hlen(cart_key)



        context = {
            'type':type,
            'types':types,
            'new_skus':new_skus,
            'skus':page_list,
            'cart_count':cart_count,
            'sort':sort,
            'page_num':page_num,
            'num':num,
        }

        return render(request,'list.html',context)
