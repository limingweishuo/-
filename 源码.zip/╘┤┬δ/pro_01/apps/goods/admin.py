from django.contrib import admin
from django.core.cache import cache
from goods.models import GoodsType, GoodsSKU, Goods, GoodsImage, IndexGoodsBanner, IndexTypeGoodsBanner,IndexPromotionBanner

# Register your models here.

class BaseModelAdmin(admin.ModelAdmin):
    def save_model(self, request, obj, form, change):
        # 添加或更新时重新条用
        super().save_model(request, obj, form, change)

        cache.delete('index_page_info')

    def delete_model(self, request, obj):
        # 删除时调用
        super().delete_model(request, obj)

        cache.delete('index_page_info')


admin.site.register(GoodsType,BaseModelAdmin)
admin.site.register(GoodsSKU,BaseModelAdmin)
admin.site.register(Goods,BaseModelAdmin)
admin.site.register(GoodsImage,BaseModelAdmin)
admin.site.register(IndexGoodsBanner,BaseModelAdmin)
admin.site.register(IndexTypeGoodsBanner,BaseModelAdmin)
admin.site.register(IndexPromotionBanner,BaseModelAdmin)