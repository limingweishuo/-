import jsonpickle
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views import View

# Create your views here.
from django_redis import get_redis_connection

from goods.models import GoodsSKU


class CartAdd(View):
    '''添加购物车'''
    def post(self,request):

        if 'user' not in request.session:
            return JsonResponse({'res':0,'errmsg':'请先登录'})

        user = jsonpickle.loads(request.session.get('user'))

        sku_id = request.POST.get('sku_id')
        count = request.POST.get('count')

        if not all([sku_id,count]):
            return JsonResponse({'res':1,'errmsg':'信息不完整'})

        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res': 2, 'errmsg': '商品不存在'})

        try:
            count = int(count)
        except Exception as e:
            return JsonResponse({'res': 3, 'errmsg': '数量有误'})

        con = get_redis_connection('default')
        cart_key = 'cart_%d'%user.id

        cart_count = con.hget(cart_key,sku_id)

        if cart_count:
            count += int(cart_count)

        if sku.stock < count:
            return JsonResponse({'res': 4, 'errmsg': '库存已无'})

        con.hset(cart_key,sku_id,count)

        total_count = con.hlen(cart_key)

        return JsonResponse({'res':5,'total_count':total_count,'message':'添加成功'})


class CartInfo(View):
    '''购物车展示'''
    def get(self,request):

        # 判断登录
        if 'user' not in request.session:
            return redirect('/user/login/')

        user = jsonpickle.loads(request.session.get('user',''))

        # 操作redis数据库
        con = get_redis_connection('default')
        cart_key = 'cart_%d'%user.id

        cart_dict = con.hgetall(cart_key)


        skus = []
        total_price = 0
        total_count = 0

        for sku_id,count in cart_dict.items():

            sku_id = int(sku_id)

            sku = GoodsSKU.objects.get(id=sku_id)

            count = int(count)

            amount = sku.price*count

            sku.count = count
            sku.amount = amount

            skus.append(sku)

            total_price += amount
            total_count += count

        context = {
            'skus':skus,
            'total_price':total_price,
            'total_count':total_count,
        }

        return render(request,'cart.html',context)


class CartUpdate(View):
    '''购物车更新'''
    def post(self,request):
        # 判断是否登录
        if 'user' not in request.session:
            return JsonResponse({'res':0,'errmsg':'请登录'})

        user = jsonpickle.loads(request.session.get('user',''))

        # 接受参数
        sku_id = request.POST.get('sku_id','')
        count = request.POST.get('count','')

        # 校验数据
        if not all([sku_id,count]):
            return JsonResponse({'res': 1, 'errmsg': '信息不完整'})

        try:
            count = int(count)
        except Exception as e:
            return JsonResponse({'res': 2, 'errmsg': '数量有误'})

        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res': 3, 'errmsg': '商品不存在'})

        if sku.stock < count:
            return JsonResponse({'res': 4, 'errmsg': '库存不足'})

        # 链接数据库
        con = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        con.hset(cart_key, sku_id,count) # 添加

        total_count = 0
        vals = con.hvals(cart_key) # 获取数据的value值

        for val in vals:
            total_count += int(val)



        return JsonResponse({'res': 5, 'message': '更新成功','total_count':total_count})


class CartDelete(View):
    '''购物车记录删除'''
    def post(self,request):
        # 判断用户是否登录
        if 'user' not in request.session:
            return JsonResponse({'res':0,'errmsg':'请先登录'})

        user = jsonpickle.loads(request.session.get('user',''))

        # 获取参数
        sku_id = request.POST.get('sku_id')

        # 数据校验
        if not sku_id:
            return JsonResponse({'res':1,'errmsg':'无效的商品ID'})

        # 校验商品是否存在
        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res':2,'errmsg':'商品不存在'})

        # 业务处理：删除购物车记录
        con = get_redis_connection('default')
        cart_key  = 'cart_%d'%user.id
        # 删除 hdel
        con.hdel(cart_key,sku_id)

        # 计算用户购物车中商品的总件数
        total_count =0
        vals = con.hvals(cart_key)
        for val in vals:
            total_count += int(val)

        return JsonResponse({'res':3,'total_count':total_count,'message':'删除成功'})




