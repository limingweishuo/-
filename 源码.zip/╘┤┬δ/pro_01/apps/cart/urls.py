from django.urls import path
from .import views

urlpatterns = [
    path('add/',views.CartAdd.as_view()), # 添加购物车
    path('info/',views.CartInfo.as_view()), # 购物车展示
    path('update/',views.CartUpdate.as_view()), # 购物车更新
    path('delete/',views.CartDelete.as_view()), # 购物车记录删除
]