from django.urls import path
from .import views
urlpatterns = [
    path('place/',views.OrderPlace.as_view()), # 订单页
    path('commit/',views.OrderCommit.as_view()), # 创建订单
    path('pay/',views.OrderPay.as_view()), # 订单支付
    path('checkpay/',views.CheckPay.as_view()), # 获取支付结果
    path('comment/<order_id>',views.ComMent.as_view()), # 订单评论
]