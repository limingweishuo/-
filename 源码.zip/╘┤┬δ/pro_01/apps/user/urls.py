from django.urls import path
from .import views

urlpatterns = [
    path('register/',views.RegisterView.as_view()), # 注册
    path('active/<token>',views.ActiveView.as_view()), # 激活邮件
    path('login/',views.LoginView.as_view()), # 激活邮件
    path('login_out/',views.LoginOut.as_view()), # 退出登录
    path('',views.UserInfo.as_view()), # 用户中心-个人信息
    path('order/<num>',views.UserOrder.as_view()), # 用户中心-全部订单
    path('address/',views.UserAddr.as_view()), # 用户中心-收货地址
    path('code_user/',views.CodeUser.as_view()), # username验证
    path('code_email/',views.CodeEmail.as_view()), # emai验证
]