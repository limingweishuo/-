import math
import re
import jsonpickle
from django.core.mail import send_mail
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views import View
from django_redis import get_redis_connection

from goods.models import GoodsSKU
from order.models import OrderInfo, OrderGoods
from pro_01 import settings
from user.models import User, Address
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer,SignatureExpired

# Create your views here.


class RegisterView(View):
    '''注册模型类'''
    def get(self,request):
        return render(request,'register.html')

    def post(self,request):
        # 接受数据
        username = request.POST.get('user_name','')
        password = request.POST.get('pwd')
        cpwd = request.POST.get('cpwd','')
        email = request.POST.get('email','')
        allow = request.POST.get('allow','')

        # 数据校验
        # if not all([username,password,cpwd,email,allow]):
        #     return render(request,'register.html',{'errmsg':'信息不完整'})
        #
        # if cpwd != password:
        #     return render(request, 'register.html', {'errmsg': '两次密码不一致'})
        #
        # if allow != 'on':
        #     return render(request, 'register.html', {'errmsg': '请勾选'})

        try:
            user = User.objects.create(username=username,password=password,email=email)
             # print(user.id)
        except User.DoesNotExist:
            return render(request,'register.html',{'errmsg':'注册模块异常'})

        # 给用户信息加密
        # http://127.0.0.1:8000/user/active/xxx
        serializer = Serializer(settings.SECRET_KEY,3600)
        info = {'confirm':user.id}
        token = serializer.dumps(info)
        token = token.decode()

        # 发送邮件
        subject = '欢迎登陆良食速运~' # 欢迎信息
        message = '' # 邮件内容文本
        sender = settings.EMAIL_FROM # 发件人
        receiver = [email] # 收件人
        html_message = '<h1>%s 先生/女士，欢迎成为良食速运注册会员,请点击链接激活账户</h1><a href="http://127.0.0.1:8000/user/active/%s">http://127.0.0.1:8000/user/active/%s</a>'%(username,token,token)

        send_mail(subject, message, sender, receiver,html_message=html_message)

        return redirect('/index/')

class ActiveView(View):
    '''激活邮件'''
    def get(self,request,token):
        # 获取密钥
        serializer = Serializer(settings.SECRET_KEY, 3600)
        try:
            info = serializer.loads(token)
            user_id = info['confirm']
            user = User.objects.get(id=user_id)
            user.is_active = 1
            user.save()

            return redirect('/user/login/')

        except SignatureExpired as e:
            # 激活时间过期
            return HttpResponse('激活时间过期')


class LoginView(View):
    '''登陆'''
    def get(self,request):
        if 'username' in request.COOKIES and 'password' in request.COOKIES:
            username = request.COOKIES['username']
            password = request.COOKIES['password']
            checked = 'checked'
        else:
            username=''
            password=''
            checked=''

        return render(request,'login.html',{'username':username,'password':password,'checked':checked})

    def post(self,request):
        # 接受数据
        username = request.POST.get('username','')
        pwd = request.POST.get('pwd','')
        remember = request.POST.get('remember','')

        # 数据校验
        if not all([username,pwd]):
            return render(request,'login.html',{'errmsg':'信息不完整'})

        try:
            user = User.objects.get(username=username,password=pwd)
        except User.DoesNotExist:
            return render(request, 'login.html', {'errmsg': '用户不存在'})

        if user.is_active == False:
            return render(request, 'login.html', {'errmsg': '账号未激活'})

        # 设置session
        request.session['user'] = jsonpickle.dumps(user)

        res = redirect('/index/')

        if remember == 'on':
            res.set_cookie('username',username,max_age=3600)
            res.set_cookie('password',pwd,max_age=3600)
        else:
            res.delete_cookie('username')
            res.delete_cookie('password')

        return res


class CodeUser(View):
    '''注册用户名验证'''
    def get(self,request):

        username = request.GET.get('username','')

        user = User.objects.filter(username=username)

        flag = False
        passwd = ''

        if user:
            flag = True

            for u in user:
                passwd = u.password

        return JsonResponse({'flag':flag,'passwd':passwd})


class CodeEmail(View):
    '''注册邮箱验证'''
    def get(self, request):
        email = request.GET.get('email', '')

        user = User.objects.filter(email=email)

        flag = False

        if user:
            flag = True

        return JsonResponse({'flag': flag})


class LoginOut(View):
    '''退出登录'''
    def get(self,request):
        # del request.session['user']
        request.session.flush()
        # request.session.clear()

        return render(request,'login.html')

class UserInfo(View):
    '''用户中心-个人信息'''
    def get(self,request):
        # 判断用户是否登录
        if 'user' not in request.session:
            return redirect('/user/login/')

        # 获取session
        user = jsonpickle.loads(request.session.get('user',''))

        try:
            address = Address.objects.get(user=user,is_default=True)
        except Address.DoesNotExist:
            address = None
            
        '''
            获取用户历史浏览记录
        '''
        con = get_redis_connection('default') # 链接redis数据库
        history_key = 'history_%d'%user.id # 设置获取数据格式

        # 获取用户最新浏览的5个商品 id
        # lrange 从左边取值 从下标0开始拿到4 ,共计5个
        # 返回列表
        sku_ids = con.lrange(history_key,0,4)

        goods_list = []
        for id in sku_ids:
            goods = GoodsSKU.objects.get(id=id)
            goods_list.append(goods)



        return render(request,'user_center_info.html',{'page':'info','address':address,'goods_list':goods_list})

class UserOrder(View):
    '''用户中心-全部订单'''
    def get(self,request,num):
        # 判断用户是否登录
        if 'user' not in request.session:
            return redirect('/user/login/')

        user = jsonpickle.loads(request.session.get('user',''))
        # 获取用户的订单信息
        orders = OrderInfo.objects.filter(user=user).order_by('-create_time')

        # 遍历获取订单商品的信息
        for order in orders:
            # 根据order_id查询订单商品的信息
            order_skus = OrderGoods.objects.filter(order_id=order.order_id)

            # 遍历order_skus 计算商品的小计
            for order_sku in order_skus:
                # 计算小计
                amount = order_sku.price * order_sku.count
                order_sku.amount = amount

            # 动态给order增加属性，保存订单商品的小计
            order.status_name = OrderInfo.ORDER_STATUS[order.order_status]
            # 动态给order增加属性，保存订单商品的信息
            order.order_skus = order_skus

        # 组织上下文
            # 分页
            page_orders = Paginator(orders, 1)
            num = int(num)

            try:
                page_list = page_orders.page(num)
            except PageNotAnInteger:
                page_list = page_orders.page(1)
            except EmptyPage:
                page_list = page_orders.page(page_orders.num_pages)

            begin = (num - int(math.ceil(4.0 / 2)))
            if begin < 1:
                begin = 1

            end = begin + 3
            if end > page_orders.num_pages:
                end = page_orders.num_pages
            if end <= 4:
                begin = 1
            else:
                begin = end - 3
            page_num = range(begin, end + 1)

            # 组织上下文
            context = {
                'orders': page_list,
                'num': num,
                'page_num': page_num,
                'page': 'order',
            }

        return render(request,'user_center_order.html',context)


class UserAddr(View):
    '''用户中心-收货地址'''
    def get(self,request):

        if 'user' not in request.session:
            return redirect('/user/login/')

        user = jsonpickle.loads(request.session.get('user',''))

        try:
            address = Address.objects.get(user=user,is_default=True)
        except Address.DoesNotExist:
            return render(request, 'user_center_site.html', {'errmsg': '无地址'})

        return render(request,'user_center_site.html',{'page':'address','address':address})

    def post(self,request):
        # 接受数据
        receiver = request.POST.get('receiver','')
        addr = request.POST.get('address','')
        zip_code = request.POST.get('zip_code','')
        phone = request.POST.get('phone','')
        # 校验数据
        if not all([receiver,addr,zip_code,phone]):
            return render(request,'user_center_site.html',{'errmsg':'信息不完整'})

        if not re.match(r'^1[1|3|5|7|8][0-9]{9}$',phone):
            return render(request, 'user_center_site.html', {'errmsg': '手机格式错误'})

        # 有默认地址 就以默认地址形式插入

        # 获取 session
        user = jsonpickle.loads(request.session.get('user', ''))

        try:
            address = Address.objects.get(user=user,is_default=True)
        except Address.DoesNotExist:
            address = None

        if address:
            is_default = False
        else:
            is_default = True

        try:
            Address.objects.create(user=user,receiver=receiver,addr=addr,zip_code=zip_code,phone=phone,is_default=is_default)
        except Address.DoesNotExist:
            return render(request, 'user_center_site.html', {'errmsg': '添加失败'})

        return redirect('/user/address/')













